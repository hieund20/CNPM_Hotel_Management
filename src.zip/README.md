# python_hotel_management

Bài tập lớn môn Công nghệ phần mềm

<b>1. Cách download code về, up code lên github</b> 

- Chạy lệnh git clone urlrepo để clone repository về (urlrepo là url của repository này)
  <br/>
  ---> Enter
- Để Push code lên github, chạy các lệnh: 
  <br/>
  git add .
  <br/>
  ---> Enter
  <br/>
  git commit -m"trong này nhớ nhập lý do push code lên nhé (VD: upload code/fix bug gì gì dó/add new featuer, ....)"
  <br/>
  ---> Enter
  <br/>
  git push
  <br/>
  ---> Enter
  <br/>
 Cuối cùng, để kiểm tra code đã lên repo thành công hay chưa, hãy gõ lệnh: git status nhé
- Quan trọng, nhớ chạy lệnh:
   <br/>
  git pull 
  <br/>
  ---> Enter
  <br/>
  để cập nhật code mới trước mỗi lần code nha !!
  
<b>2. Cách tạo nhánh (branch) để code cho tính năng của mình</b> 

